var that = this
Page({
  data: {
    showTopTips: false,

    radioItems: [
      { name: 'cell standard', value: '0' },
      { name: 'cell standard', value: '1', checked: true }
    ],
    checkboxItems: [
      { name: 'standard is dealt for u.', value: '0', checked: true },
      { name: 'standard is dealicient for u.', value: '1' }
    ],

    date: "2016-09-01",
    time: "12:01",

    countryCodes: ["+86", "+80", "+84", "+87"],
    countryCodeIndex: 0,

    countries: ["中国", "美国", "英国"],
    countryIndex: 0,

    accounts: ["微信号", "QQ", "Email"],
    accountIndex: 0,

    isAgree: false
  },
  showTopTips: function () {
    var that = this;
    this.setData({
      showTopTips: true
    });
    setTimeout(function () {
      that.setData({
        showTopTips: false
      });
    }, 3000);
  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value);

    var radioItems = this.data.radioItems;
    for (var i = 0, len = radioItems.length; i < len; ++i) {
      radioItems[i].checked = radioItems[i].value == e.detail.value;
    }

    this.setData({
      radioItems: radioItems
    });
  },
  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);

    var checkboxItems = this.data.checkboxItems, values = e.detail.value;
    for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
      checkboxItems[i].checked = false;

      for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
        if (checkboxItems[i].value == values[j]) {
          checkboxItems[i].checked = true;
          break;
        }
      }
    }

    this.setData({
      checkboxItems: checkboxItems
    });
  },
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
  },
  bindTimeChange: function (e) {
    this.setData({
      time: e.detail.value
    })
  },
  bindCountryCodeChange: function (e) {
    console.log('picker country code 发生选择改变，携带值为', e.detail.value);

    this.setData({
      countryCodeIndex: e.detail.value
    })
  },
  bindCountryChange: function (e) {
    console.log('picker country 发生选择改变，携带值为', e.detail.value);

    this.setData({
      countryIndex: e.detail.value
    })
  },
  bindAccountChange: function (e) {
    console.log('picker account 发生选择改变，携带值为', e.detail.value);

    this.setData({
      accountIndex: e.detail.value
    })
  },
  bindAgreeChange: function (e) {
    this.setData({
      isAgree: !!e.detail.value.length
    });
  },





  globalData: {
    isTouch: false,//默认是false, 可点击
  },
  globalData: {
    point: false,//默认是false, 可点击
  },
  data: {
    items: [
      { name: 'get', value:'' },
    ]
  },
 
  checkboxChange: function (e) {
    var agree = e.detail.value;
    console.log(e.detail.value)
    this.setData({
      useragree:agree,
    })
  },
  userNameInput: function (e) { //wxml传入数据
    this.setData({
      userName: e.detail.value  
    })
  },
  userShoeInput: function (e) { //wxml传入数据
    this.setData({
      userShoe: e.detail.value
    })
  },
  userPhoneInput: function (e) {
    this.setData({
      userPhone: e.detail.value,
    })
    this.setData({
      t1: e.detail.value.length,
    })
    console.log(t1)
  },
  userLocalInput: function (e) {
    this.setData({
      userLocal: e.detail.value
    })
  },
//点击事件

  bindtest: function (){
    if ((this.data.userName == null) || (this.data.userPhone == null) || (this.data.userLocal == null) || (this.data.t1 != 11) ||(this.data.useragree!='get') ){
       showok: {
        wx.showToast({
          title: '请填写完整数据哦!(检查手机号是否输入有误,是否已同意条款)',
          icon: 'none',
          mask: true,
          duration: 2500
        })
      }
   //wxml传入数据
      setTimeout(function (e) {
    
      }, 2501)
      return
    }
    else if(this.data.userShoe<=0){
      showok: {
        wx.showToast({
          title: '鞋子数量不正确哦',
          icon: 'none',
          mask: true,
          duration: 2500
        })
      }

      setTimeout(function (e) {

      }, 2501)
      return
    } 
  wx.showLoading({ title: '加载中', icon: 'loading', duration: 50000,mask:true }); //点击弹出loading,禁止操作
  let that = this
  if (!this.data.isTouch) {      //如果是false,切换到true(无法点击,防止重复提交)
    this.setData({
      isTouch: true   //
    }, () => {
      //如果是false就发送请求
      wx.cloud.callFunction({ //调用云函数,request
        name: 'https',
        data: {
          username: this.data.userName,
          userphone: this.data.userPhone,
          userlocal: this.data.userLocal,
          usershoe:this.data.userShoe
        },
        success:(res)=>{
          console.log(res.result)
          if (res.result == null && res.result != 'undefined'  ){
            wx.reLaunch({
              url: '/pages/index/index',
            })
            wx.hideLoading()
            wx.showModal({
              title: '预约失败,请稍后重试',
              content: '',
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  console.log('关闭')
                  
                }
              }
            })
          }else if(res.result == 1){
            console.log(res.result)
            wx.hideLoading()
            wx.reLaunch({
              url: '/pages/success_msg/success_msg',
            })
          }
        },fail:(res) =>{
          console.log(res.result)
          
          wx.reLaunch({
            url: '/pages/index/index',
          })
          wx.hideLoading()
            wx.showModal({
            title: '预约失败,请稍后重试',
            content: '',
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                console.log('关闭')
                
                
              }
            }
          })
          
          //wx.reLaunch({
            //url: '/pages/success_msg/success_msg',
          //})
        }
      })
      
    })
  } 
  
 
}
})